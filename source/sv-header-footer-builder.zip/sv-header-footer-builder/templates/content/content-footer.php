<?php
/**
 * Content Footer
 *
 * Handle Footer (reviews and order notes).
 *
 * @package Boostify_Header_Footer_Template
 *
 * Written by ptp
 */

?>
<footer id="mastfooter" class="boostify-site-footer">
	<div class="boostify-footer-inner">
		<?php the_content(); ?>
	</div>
</footer>

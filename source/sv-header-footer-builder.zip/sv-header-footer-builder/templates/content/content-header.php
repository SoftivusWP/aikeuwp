<?php
/**
 * Content Header
 *
 * Handle Header (reviews and order notes).
 *
 * @package Boostify_Header_Footer_Template
 *
 * Written by ptp
 */

?>
<header id="masthead" class="boostify-site-header">
	<?php the_content(); ?>
</header>

<?php
/**
 * Content Sub Menu
 *
 * Handle Sub Menu (reviews and order notes).
 *
 * @package Boostify_Header_Footer_Template
 *
 * Written by ptp
 */

?>
<ul class="sub-menu boostify-sub-menu sub-mega-menu">
	<?php the_content(); ?>
</ul>

</main>
<?php

/**
 * Footer Site
 *
 * Handle Footer Site.
 *
 * @package Boostify_Header_Footer_Template
 *
 * Written by ptp
 */

do_action('boostify_hf_get_footer');
?>
</div>

<?php
do_action('boostify_hf_footer');

wp_footer();


?>
<!-- smooth-wrapper -->
</div>
</div>
<!-- my-app -->
</div>
</body>

</html>